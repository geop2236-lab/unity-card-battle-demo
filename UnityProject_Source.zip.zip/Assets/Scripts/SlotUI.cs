using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SlotUI : MonoBehaviour, IDropHandler
{
    public int slotIndex;
    public bool isPlayerSlot = true;

    private void Awake()
    {
        Debug.Log($"[SlotUI Awake] �����ˣ�������={gameObject.name}", this);

        Image img = GetComponent<Image>();
        if (img == null)
        {
            img = gameObject.AddComponent<Image>();
        }

        img.color = new Color(0f, 0f, 0f, 0.35f);
        img.raycastTarget = true;

        Debug.Log($"[SlotUI Awake] �����ú�׺� RaycastTarget��{gameObject.name}", this);
    }

    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log($"[SlotUI] �յ� Drop����λ={slotIndex}");

        GameObject droppedObj = eventData.pointerDrag;
        if (droppedObj == null)
        {
            Debug.LogWarning("[SlotUI] pointerDrag �ǿ�");
            return;
        }

        Draggable draggable = droppedObj.GetComponent<Draggable>();
        if (draggable != null)
        {
            Debug.Log("[SlotUI] ʶ������ Draggable");
            draggable.OnDropOnSlot(this);
            return;
        }

        LaneCardDraggable laneDrag = droppedObj.GetComponent<LaneCardDraggable>();
        if (laneDrag != null)
        {
            Debug.Log("[SlotUI] ʶ�𵽲��ڿ� LaneCardDraggable");
            laneDrag.OnDropOnSlot(this);
            return;
        }

        Debug.LogError($"[SlotUI] �Ҳ����ɴ�������ק�����{droppedObj.name}");
    }
}
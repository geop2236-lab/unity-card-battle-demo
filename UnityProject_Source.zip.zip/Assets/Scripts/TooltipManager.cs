using UnityEngine;
using TMPro;

public class TooltipManager : MonoBehaviour
{
    public static TooltipManager Instance { get; private set; }

    [Header("UI ����")]
    public GameObject tooltipPanel; // ���� TooltipPanel ����
    public TextMeshProUGUI titleText;
    public TextMeshProUGUI descText;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        // ��Ϸ��ʼʱȷ������
        HideTooltip();
    }

    // ��ʾ��ʾ��
    public void ShowTooltip(CardData cardData)
    {
        if (cardData == null) return;

        titleText.text = cardData.cardName;
        descText.text = cardData.description;

        tooltipPanel.SetActive(true);
    }

    // ������ʾ��
    public void HideTooltip()
    {
        tooltipPanel.SetActive(false);
    }
}
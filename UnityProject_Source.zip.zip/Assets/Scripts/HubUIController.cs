using TMPro;
using UnityEngine;

public class HubUIController : MonoBehaviour
{
    public TextMeshProUGUI dayText;

    void Start()
    {
        RefreshUI();
    }

    public void RefreshUI()
    {
        if (RunDataManager.Instance == null) return;

        dayText.text = $"Day {RunDataManager.Instance.currentDay}/{RunDataManager.Instance.maxDay}";
    }
}
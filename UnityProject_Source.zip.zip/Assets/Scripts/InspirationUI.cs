using UnityEngine;
using TMPro; // �� UnityEngine.UI
using UnityEngine.UI;

public class InspirationUI : MonoBehaviour
{
    [Header("��Դ��ʾ")]
    public TextMeshProUGUI redText;
    public TextMeshProUGUI yellowText;
    public TextMeshProUGUI blueText;

    [Header("�ϳ��б�")]
    public Transform recipeRoot; // ���ð�ť�ĸ�����
    public GameObject recipeButtonPrefab; // ��ťԤ�Ƽ�

    void Start()
    {
        if (InspirationManager.Instance != null)
        {
            InspirationManager.Instance.OnPointsChanged += RefreshUI;
            RefreshUI();
        }

        if (RunDataManager.Instance != null)
        {
            RunDataManager.Instance.OnRecipesChanged += InitRecipeList;
        }

        InitRecipeList();
    }

    void RefreshUI()
    {
        if (InspirationManager.Instance == null) return;

        redText.text = InspirationManager.Instance.redPoints.ToString();
        yellowText.text = InspirationManager.Instance.yellowPoints.ToString();
        blueText.text = InspirationManager.Instance.bluePoints.ToString();
    }

    public void InitRecipeList()
    {
        // ��վɰ�ť
        foreach (Transform child in recipeRoot) Destroy(child.gameObject);

        var recipes = InspirationManager.Instance.GetUnlockedRecipes();
        for (int i = 0; i < recipes.Count; i++)
        {
            var recipe = recipes[i];
            CardData card = recipe.resultCard;

            // ���ɰ�ť
            GameObject btnObj = Instantiate(recipeButtonPrefab, recipeRoot);

            // �������֣����� + ����
            // ����: "��ն (R:3 Y:0 B:0)"
            string costStr = $"<color=red>R{card.costRed}</color> <color=yellow>Y{card.costYellow}</color> <color=blue>B{card.costBlue}</color>";
            btnObj.GetComponentInChildren<TextMeshProUGUI>().text = $"{card.cardName}\n{costStr}";

            // �󶨵���¼�
            Button btn = btnObj.GetComponent<Button>();
            btn.onClick.AddListener(() => {
                InspirationManager.Instance.CraftCardByData(card);
            });
        }
    }

    void OnDestroy()
    {
        if (InspirationManager.Instance != null)
            InspirationManager.Instance.OnPointsChanged -= RefreshUI;

        if (RunDataManager.Instance != null)
            RunDataManager.Instance.OnRecipesChanged -= InitRecipeList;
    }
}
using UnityEngine;

public class BattleFXManager : MonoBehaviour
{
    public static BattleFXManager Instance { get; private set; }

    [Header("����")]
    public GameObject damageTextPrefab;
    public Canvas mainCanvas;

    void Awake()
    {
        if (Instance == null) Instance = this;
    }

    public void SpawnDamageText(int amount, Vector3 worldPos, bool isPlayerDamage)
    {
        GameObject obj = Instantiate(damageTextPrefab, mainCanvas.transform);

        Vector2 screenPos = Camera.main.WorldToScreenPoint(worldPos);
        obj.transform.position = screenPos;

        FloatingText ft = obj.GetComponent<FloatingText>();
        Color c = isPlayerDamage ? Color.red : Color.yellow;
        ft.Init(amount, c);
    }

    public void SpawnDebrisText(int amount, Vector3 worldPos, bool isPlayerTarget)
    {
        GameObject obj = Instantiate(damageTextPrefab, mainCanvas.transform);

        Vector2 screenPos = Camera.main.WorldToScreenPoint(worldPos);
        // ��΢����ƫһ�㣬������˺�Ʈ����ȫ�ص�
        obj.transform.position = screenPos + new Vector2(60f, 0f);

        FloatingText ft = obj.GetComponent<FloatingText>();
        Color c = isPlayerTarget ? new Color(1f, 0.5f, 0.5f) : new Color(0.6f, 1f, 1f);
        ft.Init($"+{amount}waste card", c);
    }
}
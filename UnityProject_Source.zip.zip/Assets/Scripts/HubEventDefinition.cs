using UnityEngine;

[CreateAssetMenu(fileName = "HubEventDefinition", menuName = "Game/Hub Event Definition")]
public class HubEventDefinition : ScriptableObject
{
    public string eventName;
    [TextArea] public string description;

    public HubEventType eventType;

    [Header("奖励/战斗内容")]
    public CardData rewardCard;
    public EnemyData enemyData;
}

public enum HubEventType
{
    GetCard,
    GetRecipe,
    Battle
}
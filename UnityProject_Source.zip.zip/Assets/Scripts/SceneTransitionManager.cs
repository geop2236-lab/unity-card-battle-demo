using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using DG.Tweening;
using UnityEngine.UI;

public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance { get; private set; }

    [Header("引用")]
    public RectTransform curtainPanel;
    public Canvas transitionCanvas;
    public Image curtainImage;

    [Header("时间设置")]
    public float slideInDuration = 0.5f;
    public float holdDuration = 0.3f;
    public float slideOutDuration = 0.5f;

    [Header("颜色设置")]
    public Color curtainColor = new Color(0.95f, 0.95f, 0.95f, 1f);

    private bool isTransitioning = false;
    private float panelWidth;
    private Vector2 centerPos = Vector2.zero;
    private Vector2 leftHiddenPos;
    private Vector2 rightHiddenPos;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializePositions();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        if (curtainImage != null)
        {
            curtainImage.color = curtainColor;
        }

        if (curtainPanel != null)
        {
            curtainPanel.anchoredPosition = leftHiddenPos;
        }
    }

    private void InitializePositions()
    {
        if (curtainPanel == null) return;

        panelWidth = curtainPanel.rect.width;
        if (panelWidth <= 0f) panelWidth = 3500f;

        leftHiddenPos = new Vector2(-2 * panelWidth, 0f);
        rightHiddenPos = new Vector2(2 * panelWidth, 0f);
        centerPos = Vector2.zero;
    }

    public void TransitionToScene(string sceneName)
    {
        if (isTransitioning) return;
        StartCoroutine(TransitionRoutine(sceneName));
    }

    private IEnumerator TransitionRoutine(string sceneName)
    {
        isTransitioning = true;

        if (curtainPanel == null)
        {
            SceneManager.LoadScene(sceneName);
            isTransitioning = false;
            yield break;
        }

        curtainPanel.SetAsLastSibling();
        curtainPanel.anchoredPosition = leftHiddenPos;

        // 幕布滑入
        yield return curtainPanel.DOAnchorPos(centerPos, slideInDuration)
            .SetEase(Ease.InOutSine)
            .WaitForCompletion();

        // 稍微停顿
        yield return new WaitForSeconds(holdDuration);

        // 切场景
        AsyncOperation loadOp = SceneManager.LoadSceneAsync(sceneName);
        while (!loadOp.isDone)
        {
            yield return null;
        }

        // 新场景加载完后再停一小下，防止闪
        yield return new WaitForSeconds(0.05f);

        // 幕布滑出
        yield return curtainPanel.DOAnchorPos(rightHiddenPos, slideOutDuration)
            .SetEase(Ease.InOutSine)
            .WaitForCompletion();

        // 重置回左侧，方便下次使用
        curtainPanel.anchoredPosition = leftHiddenPos;

        isTransitioning = false;
    }
}
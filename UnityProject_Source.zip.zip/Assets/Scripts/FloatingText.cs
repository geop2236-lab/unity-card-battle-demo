using UnityEngine;
using TMPro;
using DG.Tweening;

public class FloatingText : MonoBehaviour
{
    public TextMeshProUGUI tmp;
    public CanvasGroup canvasGroup;

    public void Init(string text, Color color)
    {
        tmp.text = text;
        tmp.color = color;
        canvasGroup.alpha = 1;

        transform.DOMoveY(transform.position.y + 2.0f, 1.0f).SetEase(Ease.OutCirc);

        transform.localScale = Vector3.one;
        transform.DOPunchScale(Vector3.one * 0.5f, 0.3f);

        canvasGroup.DOFade(0, 0.5f).SetDelay(0.5f).OnComplete(() => {
            Destroy(gameObject);
        });
    }

    public void Init(int amount, Color color)
    {
        Init(amount.ToString(), color);
    }
}
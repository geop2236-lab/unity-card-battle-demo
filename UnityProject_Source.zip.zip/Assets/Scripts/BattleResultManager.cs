using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BattleResultManager : MonoBehaviour
{
    public static BattleResultManager Instance { get; private set; }

    [Header("结算UI")]
    public GameObject resultPanel;
    public TMPro.TextMeshProUGUI resultText;
    public UnityEngine.UI.Button continueButton;
    public TMPro.TextMeshProUGUI continueButtonText;

    [Header("胜利奖励池 - 卡牌")]
    public List<CardData> battleRewardCards = new List<CardData>();

    [Header("胜利奖励池 - 配方")]
    public List<CardData> battleRewardRecipes = new List<CardData>();

    [Header("奖励概率")]
    [Range(0f, 1f)] public float recipeRewardChance = 0.3f;
    [Header("场景名")]
    public string hubSceneName = "HubScene";
    public string endSceneName = "EndScene";

    private bool hasHandledResult = false;
    private bool isExitingBattle = false;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        if (resultPanel != null)
            resultPanel.SetActive(false);
    }

    private void Update()
    {
        if (hasHandledResult) return;
        if (GameManager.Instance == null) return;

        if (GameManager.Instance.currentState == GameState.Win)
        {
            hasHandledResult = true;
            ShowVictoryPanel();
        }
        else if (GameManager.Instance.currentState == GameState.Loss)
        {
            hasHandledResult = true;
            ShowDefeatPanel();
        }
    }

    private void ShowVictoryPanel()
    {
        if (resultPanel != null) resultPanel.SetActive(true);
        if (resultText != null) resultText.text = "WIN";
        if (continueButtonText != null) continueButtonText.text = "Continue";

        continueButton.onClick.RemoveAllListeners();
        continueButton.onClick.AddListener(OnVictoryContinue);

        Debug.Log("[BattleResultManager] 战斗胜利，显示结算页");
    }

    private void ShowDefeatPanel()
    {
        if (resultPanel != null) resultPanel.SetActive(true);
        if (resultText != null) resultText.text = "LOSS";
        if (continueButtonText != null) continueButtonText.text = "Return to Hub";

        continueButton.onClick.RemoveAllListeners();
        continueButton.onClick.AddListener(OnDefeatContinue);

        Debug.Log("[BattleResultManager] 战斗失败，显示结算页");
    }

    private void OnVictoryContinue()
    {
        if (resultPanel != null) resultPanel.SetActive(false);

        GiveBattleReward();
    }

    private void OnDefeatContinue()
    {
        if (resultPanel != null) resultPanel.SetActive(false);

        if (RunDataManager.Instance != null)
        {
            RunDataManager.Instance.endResult = RunEndResult.Defeat;
        }

        CleanupAfterBattle();
        if (SceneFlowManager.Instance != null)
            SceneFlowManager.Instance.EnterEndScene();
        else
            UnityEngine.SceneManagement.SceneManager.LoadScene(endSceneName);
    }

    private void GiveBattleReward()
    {
        bool giveRecipe = false;

        if (battleRewardRecipes.Count > 0)
        {
            giveRecipe = Random.value < recipeRewardChance;
        }

        if (giveRecipe && battleRewardRecipes.Count > 0)
        {
            int index = Random.Range(0, battleRewardRecipes.Count);
            CardData recipeCard = battleRewardRecipes[index];

            RewardPopupUI.Instance.ShowRecipeReward(recipeCard, false, () =>
            {
                CleanupAndReturnHub(true);
            });

            Debug.Log($"[BattleResultManager] 胜利奖励：配方 {recipeCard.cardName}");
        }
        else if (battleRewardCards.Count > 0)
        {
            int index = Random.Range(0, battleRewardCards.Count);
            CardData card = battleRewardCards[index];

            RewardPopupUI.Instance.ShowCardReward(card, false, () =>
            {
                CleanupAndReturnHub(true);
            });

            Debug.Log($"[BattleResultManager] 胜利奖励：卡牌 {card.cardName}");
        }
        else
        {
            Debug.LogWarning("[BattleResultManager] 没有可用的战后奖励，直接返回Hub");
            CleanupAndReturnHub(true);
        }
    }
    private void CleanupAndReturnHub(bool advanceDay)
    {
        if (isExitingBattle) return;
        isExitingBattle = true;
        if (RunDataManager.Instance != null && GameManager.Instance != null)
        {
            RunDataManager.Instance.persistentWasteCount = GameManager.Instance.playerScrapCount;
            Debug.Log($"[BattleResultManager] 已保存跨战斗废卡数：{RunDataManager.Instance.persistentWasteCount}");
        }
        CleanupAfterBattle();

        if (advanceDay && RunDataManager.Instance != null)
        {
            RunDataManager.Instance.AdvanceDay();
            RunDataManager.Instance.StartNewDay();

            if (RunDataManager.Instance.IsRunFinished())
            {
                RunDataManager.Instance.endResult = RunEndResult.Victory;
                Debug.Log("[BattleResultManager] 已完成最终日，进入结束页");
                if (SceneFlowManager.Instance != null)
                    SceneFlowManager.Instance.EnterEndScene();
                else
                    UnityEngine.SceneManagement.SceneManager.LoadScene(endSceneName);
                return;
            }
        }

        Debug.Log($"[BattleResultManager] 准备返回场景：{hubSceneName}");
        if (SceneFlowManager.Instance != null)
            SceneFlowManager.Instance.EnterHubScene();
        else
            UnityEngine.SceneManagement.SceneManager.LoadScene(hubSceneName);
    }
    private void CleanupAndReturnHub()
    {
        CleanupAfterBattle();
        SceneFlowManager.Instance.EnterHubScene();
    }
    private void CleanupAfterBattle()
    {
        // 这里只做“清理数据”，绝对不要再调用 CleanupAndReturnHub 或 CleanupAfterBattle 自己

        if (RunDataManager.Instance != null)
        {
            RunDataManager.Instance.pendingEnemy = null;
        }

        if (PursuitFXManager.Instance != null)
        {
            PursuitFXManager.Instance.HidePursuitEffect();
        }

        Debug.Log("[BattleResultManager] 战斗清理完成");
    }
}
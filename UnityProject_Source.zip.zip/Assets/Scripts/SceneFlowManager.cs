using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneFlowManager : MonoBehaviour
{
    public static SceneFlowManager Instance { get; private set; }

    [Header("场景名")]
    public string battleSceneName = "BattleScene";
    public string hubSceneName = "HubScene";
    public string startSceneName = "StartScene";
    public string endSceneName = "EndScene";

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void EnterBattleScene()
    {
        LoadSceneWithTransition(battleSceneName);
    }

    public void EnterHubScene()
    {
        LoadSceneWithTransition(hubSceneName);
    }

    public void EnterStartScene()
    {
        LoadSceneWithTransition(startSceneName);
    }

    public void EnterEndScene()
    {
        LoadSceneWithTransition(endSceneName);
    }

    public void LoadSceneWithTransition(string sceneName)
    {
        if (SceneTransitionManager.Instance != null)
        {
            SceneTransitionManager.Instance.TransitionToScene(sceneName);
        }
        else
        {
            SceneManager.LoadScene(sceneName);
        }
    }
}
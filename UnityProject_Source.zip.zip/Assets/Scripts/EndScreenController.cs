using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndScreenController : MonoBehaviour
{
    [Header("UI")]
    public TextMeshProUGUI titleText;
    public TextMeshProUGUI descText;

    [Header("场景名")]
    public string startSceneName = "StartScene";

    void Start()
    {
        RefreshUI();
    }

    void RefreshUI()
    {
        if (RunDataManager.Instance == null)
        {
            titleText.text = "End";
            descText.text = "can't find RunDataManager";
            return;
        }

        switch (RunDataManager.Instance.endResult)
        {
            case RunEndResult.Victory:
                titleText.text = "Victory";
                descText.text = $"you made it to day {RunDataManager.Instance.maxDay} and won!";
                break;

            case RunEndResult.Defeat:
                titleText.text = "Failure";
                descText.text = $"you failed at day {RunDataManager.Instance.currentDay}.";
                break;

            default:
                titleText.text = "End";
                descText.text = "The RunDataManager is in an invalid state.";
                break;
        }
    }

    public void ReturnToTitle()
    {
        if (SceneFlowManager.Instance != null)
            SceneFlowManager.Instance.EnterStartScene();
        else
            UnityEngine.SceneManagement.SceneManager.LoadScene(startSceneName);
    }
}
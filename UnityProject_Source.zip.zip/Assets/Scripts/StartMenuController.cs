using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenuController : MonoBehaviour
{
    [Header("场景名")]
    public string hubSceneName = "HubScene";

    public void StartGame()
    {
        if (RunDataManager.Instance != null)
        {
            RunDataManager.Instance.InitializeRunData();
        }

        if (SceneFlowManager.Instance != null)
            SceneFlowManager.Instance.EnterHubScene();
        else
            UnityEngine.SceneManagement.SceneManager.LoadScene(hubSceneName);
    }

    public void QuitGame()
    {
        Debug.Log("[StartMenu] 退出游戏");
        Application.Quit();
    }
}
using DG.Tweening;
using System.Collections;
using UnityEngine;
using static BattleManager;

public class BattleManager : MonoBehaviour
{
    public static BattleManager Instance { get; private set; }
    public CardData wasteCardTemplate;
    [Header("����")]
    public float stepDelay = 1.0f; // ������
    [Header("�Ӿ��������")]
    public LaneView playerLaneView; // <--- ����
    public LaneView enemyLaneView;  // <--- ����
    [Header("�Ӿ�ê��")]
    public Transform enemyDamageAnchor; // ����ղŴ����ĵ���ͷ��������

    // ��ʱ�����õĵ��˿�
    public CardData testEnemyCard;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }
    public struct AttackResult
    {
        public int finalDamage;
        public int debris;
    }
    // �󶨸���ť�ķ���
    public void OnEndTurnButton()
    {
        // 1. ���������һغϣ����������ġ���ʼ���㡱
        if (GameManager.Instance.currentState == GameState.PlayerTurn)
        {
            GameManager.Instance.ChangeState(GameState.Resolution);
            StartCoroutine(ResolveBattleRoutine());
        }
        // 2. [����] ������ڵȴ�׷��״̬�����ǡ�����׷�����������㡱
        else if (GameManager.Instance.currentState == GameState.WaitPursuit)
        {
            Debug.Log("��ҷ���׷�������������");
            if (BattleLogManager.Instance) BattleLogManager.Instance.AddLog("<color=gray>����׷��</color>");
            if (PursuitFXManager.Instance != null) PursuitFXManager.Instance.HidePursuitEffect();
            // ��״̬�л� Resolution��while ѭ����������ͻ�⿪�����������ܣ�
            GameManager.Instance.ChangeState(GameState.Resolution);
        }
        // 3. ��ֹ�ڽ��㶯���п�㰴ť������������Э��
        else
        {
            Debug.Log("��ǰ״̬���ɲ����غϽ�����ť��");
        }
    }

    IEnumerator ResolveBattleRoutine()
    {
        Debug.Log("--- ս���׶ο�ʼ ---");

        int maxSlots = Mathf.Max(LaneManager.Instance.currentPlayerSlots, LaneManager.Instance.currentEnemySlots);
        int i = 0;

        while (i < maxSlots)
        {
            // 1. �ȼ��ʤ��
            if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                yield break;

            // 2. ������ڵ�׷������ͣ������
            while (GameManager.Instance.currentState == GameState.WaitPursuit)
            {
                yield return null;
            }

            // 3. �ٴμ��ʤ������ֹ׷���������Ѿ�Ӯ/�䣩
            if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                yield break;

            CardData playerCard = LaneManager.Instance.GetCardAt(true, i);
            CardData enemyCard = LaneManager.Instance.GetCardAt(false, i);

            if (playerCard != null || enemyCard != null)
            {
                GameObject pCardObj = playerLaneView.GetCardObject(i);
                GameObject eCardObj = enemyLaneView.GetCardObject(i);

                if (pCardObj != null)
                    pCardObj.transform.DOPunchPosition(new Vector3(50, 0, 0), 0.5f, 10, 1);

                if (eCardObj != null)
                    eCardObj.transform.DOPunchPosition(new Vector3(-50, 0, 0), 0.5f, 10, 1);

                yield return new WaitForSeconds(0.3f);

                ResolveSlot(playerCard, enemyCard);

                // 4. ResolveSlot �����꣬���̼��ʤ��
                if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                    yield break;

                // 5. ���������׷����������ԭ�صȴ�����Ҫ�����������
                while (GameManager.Instance.currentState == GameState.WaitPursuit)
                {
                    yield return null;
                }

                // 6. ׷����������ٴμ��ʤ��
                if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                    yield break;
            }

            yield return new WaitForSeconds(stepDelay);
            i++;
        }

        // 7. ����뿪ѭ��ǰ�ټ��һ�Σ���ֹ���һ��պó�ʤ��
        if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
            yield break;

        Debug.Log("--- ս���׶ν��� ---");
        EndBattlePhase();
    }

    // ---------------------------------------------------------
    // ���Ľ����߼� (�޸İ�)
    // ---------------------------------------------------------
    void ResolveSlot(CardData player, CardData enemy)
    {
        // ------------------------------------------------
        // 0. �Ͽ����㣺��Ҵ���Ͽ�ʱ������ 1 ��Ͽ���
        // ------------------------------------------------
        if (player != null && player.type == CardType.Waste)
        {
            if (GameManager.Instance.playerScrapCount > 0)
            {
                GameManager.Instance.playerScrapCount--;

                Debug.Log($"��Ҵ���Ͽ�����ǰ�Ͽ�����{GameManager.Instance.playerScrapCount}");

                if (BattleLogManager.Instance)
                {
                    BattleLogManager.Instance.AddLog("<color=gray>����Ͽ����Ͽ��� -1</color>");
                }
            }
            else
            {
                Debug.Log("��Ҵ���Ͽ�������ǰ�Ͽ�����Ϊ 0�����Ƴ�����ʵ��Ͽ�");

                if (BattleLogManager.Instance)
                {
                    BattleLogManager.Instance.AddLog("<color=gray>����Ͽ�������ǰ�Ͽ�����Ϊ 0</color>");
                }
            }
        }
        // ------------------------------------------------
        // 1. ���ܿ����� (���� / ����)
        // ------------------------------------------------
        if (player != null && player.type == CardType.Skill)
        {
            if (player.isExpandSlot)
            {
                LaneManager.Instance.ExpandLane(true, player.expandAmount);
            }

            if (player.value > 0)
            {
                GameManager.Instance.playerBlock += player.value;
                if (BattleLogManager.Instance)
                    BattleLogManager.Instance.AddLog($"<color=#55AAFF>player get {player.value} block</color>");
            }

            if (player.gainStrength > 0)
            {
                GameManager.Instance.playerStrength += player.gainStrength;
                if (BattleLogManager.Instance)
                    BattleLogManager.Instance.AddLog($"<color=orange>player gain {player.gainStrength} strength</color>");
            }
        }

        // ���˼��� (���ռ��)
        if (enemy != null && enemy.type == CardType.Skill)
        {
            if (enemy.isExpandSlot)
            {
                LaneManager.Instance.ExpandLane(false, enemy.expandAmount);
            }

            if (enemy.value > 0)
            {
                GameManager.Instance.enemyBlock += enemy.value;
                if (BattleLogManager.Instance)
                    BattleLogManager.Instance.AddLog($"<color=#55AAFF>enemy get {enemy.value} block</color>");
            }

            if (enemy.gainStrength > 0)
            {
                GameManager.Instance.enemyStrength += enemy.gainStrength;
                if (BattleLogManager.Instance)
                    BattleLogManager.Instance.AddLog($"<color=orange>enemy gain {enemy.gainStrength} strength</color>");
            }
        }

        // ------------------------------------------------
        // 2. ���� / ��������
        // ------------------------------------------------

        // �ȼ�������������� (�����null����0)
        int pAtk = (player != null && player.type == CardType.Attack) ? player.value + GameManager.Instance.playerStrength : 0;
        int eAtk = (enemy != null && enemy.type == CardType.Attack) ? enemy.value + GameManager.Instance.enemyStrength : 0;

        pAtk = Mathf.Max(0, pAtk);
        eAtk = Mathf.Max(0, eAtk);

        // --- ��ҹ����߼� ---
        int playerHitCount = (player != null && player.type == CardType.Attack) ? Mathf.Max(1, player.hitCount) : 0;

        if (pAtk > 0)
        {
            for (int hitIndex = 0; hitIndex < playerHitCount; hitIndex++)
            {
                int currentPAtk = pAtk;
                int currentEAtk = (hitIndex == 0) ? eAtk : 0; // ֻ�е�һ�β���ƴ��

                // ����ֻ�ڵ�һ���ж�
                if (hitIndex == 0 && player.isParry)
                {
                    if (currentEAtk > 0)
                    {
                        Debug.Log($"��������������: {player.parryType}");
                        if (BattleLogManager.Instance)
                            BattleLogManager.Instance.AddLog("<color=orange>parry success! type: " + player.parryType + "</color>");

                        switch (player.parryType)
                        {
                            case ParryType.DoubleDamage:
                                currentPAtk *= 2;
                                break;

                            case ParryType.ReflectDamage:
                                currentPAtk = currentEAtk * 2;
                                currentEAtk = 0;
                                Debug.Log("�����ɹ������˹�����Ч����");
                                break;

                            case ParryType.GainBlock:
                                GameManager.Instance.playerBlock += 20;
                                currentPAtk = 0;
                                break;
                        }
                    }
                    else
                    {
                        Debug.Log("����ʧ�� (�ջ�/����δ����)");
                        currentPAtk = 0;
                    }
                }

                AttackResult playerAttackResult = ProcessAttack(
                    currentPAtk,
                    currentEAtk,
                    GameManager.Instance.enemyFixedDef,
                    ref GameManager.Instance.enemyBlock,
                    GameManager.Instance.enemyTolerance
                );

                // Ʈ��ʵ���˺���
                if (playerAttackResult.finalDamage > 0)
                {
                    if (enemyDamageAnchor != null)
                    {
                        BattleFXManager.Instance.SpawnDamageText(playerAttackResult.finalDamage, enemyDamageAnchor.position, false);
                    }
                }

                // Ʈ���Ͽ�����
                if (playerAttackResult.debris > 0)
                {
                    if (EnemyManager.Instance != null)
                        EnemyManager.Instance.currentScrap += playerAttackResult.debris;

                    if (enemyDamageAnchor != null)
                    {
                        BattleFXManager.Instance.SpawnDebrisText(playerAttackResult.debris, enemyDamageAnchor.position, false);
                    }

                    if (BattleLogManager.Instance)
                        BattleLogManager.Instance.AddLog($"<color=#FF5555>to enemy {playerAttackResult.debris} scrap! (Hit {hitIndex + 1})</color>");

                    // ׷��ֻ�ڵ�һ���ж�
                    if (hitIndex == 0 && player.isPursuit && currentPAtk > currentEAtk)
                    {
                        Debug.Log("<color=orange>pursuit trigger! Please add attack!</color>");
                        if (BattleLogManager.Instance)
                            BattleLogManager.Instance.AddLog("<color=orange>pursuit trigger! Please add attack!</color>");

                        // ֻ��û�ֳ�ʤ��ʱ���Ž���׷���ȴ�
                        if (GameManager.Instance.currentState != GameState.Win &&
                            GameManager.Instance.currentState != GameState.Loss)
                        {
                            GameManager.Instance.ChangeState(GameState.WaitPursuit);

                            if (PursuitFXManager.Instance != null)
                                PursuitFXManager.Instance.ShowPursuitEffect();
                        }

                        // �ǳ��ؼ���׷��һ����������ֹͣ��ǰ���ӵĺ�������
                        return;
                    }
                }

                GameManager.Instance.CheckWinLoss();
                if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                    return;
            }
        }

        // --- ���˹����߼� ---
        int enemyHitCount = (enemy != null && enemy.type == CardType.Attack) ? Mathf.Max(1, enemy.hitCount) : 0;

        if (eAtk > 0 && enemy != null)
        {
            Vector3 playerPos = new Vector3(-3, -2, 0);

            for (int hitIndex = 0; hitIndex < enemyHitCount; hitIndex++)
            {
                int currentEAtk = eAtk;
                int currentPAtk = (hitIndex == 0) ? pAtk : 0; // ֻ�е�һ�β���ƴ��

                if (hitIndex == 0 && enemy.isParry)
                {
                    if (currentPAtk > 0) currentEAtk *= 2;
                    else currentEAtk = 0;
                }

                AttackResult enemyAttackResult = ProcessAttack(
                    currentEAtk,
                    currentPAtk,
                    GameManager.Instance.playerFixedDef,
                    ref GameManager.Instance.playerBlock,
                    GameManager.Instance.playerTolerance
                );

                // Ʈ��ʵ���˺���
                if (enemyAttackResult.finalDamage > 0)
                {
                    BattleFXManager.Instance.SpawnDamageText(enemyAttackResult.finalDamage, playerPos, true);
                }

                // Ʈ���Ͽ�����
                if (enemyAttackResult.debris > 0)
                {
                    GameManager.Instance.playerScrapCount += enemyAttackResult.debris;
                    if (DeckManager.Instance != null && DeckManager.Instance.wasteCardTemplate != null)
                    {
                        DeckManager.Instance.AddWasteCard(DeckManager.Instance.wasteCardTemplate, enemyAttackResult.debris);
                    }
                    BattleFXManager.Instance.SpawnDebrisText(enemyAttackResult.debris, playerPos, true);
                    
                    if (BattleLogManager.Instance)
                        BattleLogManager.Instance.AddLog($"<color=#FF5555>to player {enemyAttackResult.debris} scrap! (Hit {hitIndex + 1})</color>");
                }

                GameManager.Instance.CheckWinLoss();
                if (GameManager.Instance.currentState == GameState.Win || GameManager.Instance.currentState == GameState.Loss)
                    return;
            }
        }

        // ÿ�ν����궼���һ���ǲ�����͸��
        GameManager.Instance.CheckWinLoss();
    }
    AttackResult ProcessAttack(int attackVal, int counterVal, int fixedDef, ref int currentBlock, int tolerance)
    {
        AttackResult result = new AttackResult
        {
            finalDamage = 0,
            debris = 0
        };

        // 1. ƴ������
        int damageAfterClash = attackVal - counterVal;
        if (damageAfterClash <= 0) return result;

        // 2. �̶���������
        int damageAfterFixed = damageAfterClash - fixedDef;
        if (damageAfterFixed <= 0) return result;

        // 3. �񵲵���
        int damageFinal = 0;
        if (currentBlock >= damageAfterFixed)
        {
            currentBlock -= damageAfterFixed;
            damageFinal = 0;
            Debug.Log($"[��������] �񵲵�������ʣ��: {currentBlock}");
        }
        else
        {
            damageFinal = damageAfterFixed - currentBlock;
            currentBlock = 0;
            Debug.Log($"[��������] �ƶܣ�����˺�: {damageFinal}");
        }

        result.finalDamage = damageFinal;
        result.debris = BattleCalculator.ConvertDamageToDebris(damageFinal, tolerance);

        return result;
    }

    void EndBattlePhase()
    {
        if (GameManager.Instance.currentState == GameState.Win ||
            GameManager.Instance.currentState == GameState.Loss ||
            GameManager.Instance.currentState == GameState.WaitPursuit)
        {
            Debug.Log("[BattleManager] ��ǰ״̬���������� EndBattlePhase��������");
            return;
        }

        LaneManager.Instance.ClearLanes();

        if (HandManager.Instance != null)
        {
            HandManager.Instance.ClearHand();
        }

        GameManager.Instance.StartNewTurn();
    }
    public void ExecutePursuitAttack(CardData pursuitCard)
    {
        Debug.Log($"��ҷ���׷����{pursuitCard.cardName}");
        if (BattleLogManager.Instance)
            BattleLogManager.Instance.AddLog($"<color=orange>׷�ӹ�����{pursuitCard.cardName}</color>");

        int pursuitAttackValue = pursuitCard.value + GameManager.Instance.playerStrength;
        pursuitAttackValue = Mathf.Max(0, pursuitAttackValue);

        AttackResult pursuitAttackResult = ProcessAttack(
            pursuitAttackValue,
            0,
            GameManager.Instance.enemyFixedDef,
            ref GameManager.Instance.enemyBlock,
            GameManager.Instance.enemyTolerance
        );

        if (pursuitAttackResult.finalDamage > 0)
        {
            if (enemyDamageAnchor != null)
            {
                BattleFXManager.Instance.SpawnDamageText(pursuitAttackResult.finalDamage, enemyDamageAnchor.position, false);
            }
        }

        if (pursuitAttackResult.debris > 0)
        {
            if (EnemyManager.Instance != null)
                EnemyManager.Instance.currentScrap += pursuitAttackResult.debris;

            if (enemyDamageAnchor != null)
            {
                BattleFXManager.Instance.SpawnDebrisText(pursuitAttackResult.debris, enemyDamageAnchor.position, false);
            }
        }

        GameManager.Instance.CheckWinLoss();

        if (PursuitFXManager.Instance != null)
            PursuitFXManager.Instance.HidePursuitEffect();

        if (GameManager.Instance.currentState != GameState.Win &&
            GameManager.Instance.currentState != GameState.Loss)
        {
            if (GameManager.Instance.currentState == GameState.WaitPursuit)
            {
                GameManager.Instance.ChangeState(GameState.Resolution);
            }
        }
    }

    void FillEnemyLaneDummy()
    {
        // �򵥲��ԣ���������˲��Կ����͸����˵�һ����һ��
        if (testEnemyCard != null)
        {
            LaneManager.Instance.TryPlaceCard(false, 0, testEnemyCard);
        }
    }
}
using UnityEngine;
using UnityEngine.EventSystems;

public class LaneCardDraggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler
{
    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;
    private Canvas parentCanvas;
    private bool shouldDestroyAfterDrop = false;
    private Transform originalParent;
    private Vector3 originalPosition;
    private Vector2 dragOffset;
    [HideInInspector] public int slotIndex;
    [HideInInspector] public bool isPlayerLaneCard;

    private bool isDragging = false;
    private bool dropSucceeded = false;

    void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
        parentCanvas = GetComponentInParent<Canvas>();

        if (canvasGroup == null)
        {
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }
    }

    public void Setup(int index, bool isPlayer)
    {
        slotIndex = index;
        isPlayerLaneCard = isPlayer;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (!isPlayerLaneCard)
            return;

        if (GameManager.Instance.currentState != GameState.PlayerTurn)
            return;

        originalParent = transform.parent;
        originalPosition = rectTransform.position;

        // 先记录鼠标与卡牌中心的偏移
        dragOffset = (Vector2)rectTransform.position - eventData.position;

        if (parentCanvas != null)
        {
            transform.SetParent(parentCanvas.transform, true);
        }

        canvasGroup.blocksRaycasts = false;
        isDragging = true;
        dropSucceeded = false;

        Debug.Log($"[LaneCardDraggable] 开始拖拽，原槽位={slotIndex}");
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!isDragging) return;
        rectTransform.position = eventData.position + dragOffset;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (!isDragging) return;

        canvasGroup.blocksRaycasts = true;

        if (!dropSucceeded)
        {
            ReturnToOriginalParent();
            Debug.Log("[LaneCardDraggable] 结束拖拽，未成功，已回原位");
        }
        else
        {
            Debug.Log("[LaneCardDraggable] 结束拖拽，已成功换位/移动");
        }

        isDragging = false;

        if (shouldDestroyAfterDrop)
        {
            Destroy(gameObject);
        }
    }

    public void OnDropOnSlot(SlotUI slot)
    {
        Debug.Log($"[LaneCardDraggable] OnDropOnSlot 被调用，from={slotIndex}, to={slot.slotIndex}");

        if (!isPlayerLaneCard) return;
        if (!slot.isPlayerSlot) return;

        bool success = LaneManager.Instance.TryMoveCard(true, slotIndex, slot.slotIndex);

        if (success)
        {
            dropSucceeded = true;
            shouldDestroyAfterDrop = true;
            Debug.Log("[LaneCardDraggable] 移动成功，旧显示对象待销毁");
        }
        else
        {
            Debug.LogWarning("[LaneCardDraggable] 移动失败");
        }
    }

    public void OnDrop(PointerEventData eventData)
    {
        SlotUI parentSlot = GetComponentInParent<SlotUI>();
        if (parentSlot == null) return;

        GameObject droppedObj = eventData.pointerDrag;
        if (droppedObj == null) return;

        Debug.Log($"[LaneCardDraggable] 我作为目标收到了 Drop，父槽位={parentSlot.slotIndex}");

        Draggable handDrag = droppedObj.GetComponent<Draggable>();
        if (handDrag != null)
        {
            handDrag.OnDropOnSlot(parentSlot);
            return;
        }

        LaneCardDraggable laneDrag = droppedObj.GetComponent<LaneCardDraggable>();
        if (laneDrag != null && laneDrag != this)
        {
            laneDrag.OnDropOnSlot(parentSlot);
        }
    }

    private void ReturnToOriginalParent()
    {
        transform.SetParent(originalParent, true);
        rectTransform.position = originalPosition;
    }
}
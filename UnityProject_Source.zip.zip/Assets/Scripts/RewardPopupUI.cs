using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RewardPopupUI : MonoBehaviour
{
    public static RewardPopupUI Instance { get; private set; }

    [Header("UI")]
    public GameObject panelRoot;
    public Button overlayButton;          // 点击空白关闭
    public TextMeshProUGUI titleText;
    public Button acceptButton;
    public Button cancelButton;
    public TextMeshProUGUI acceptButtonText;
    public TextMeshProUGUI cancelButtonText;

    private System.Action acceptAction;
    private System.Action cancelAction;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        if (overlayButton != null)
        {
            overlayButton.onClick.RemoveAllListeners();
            overlayButton.onClick.AddListener(CloseWithoutChoice);
        }

        Hide();
    }

    public void ShowCardReward(CardData card, bool consumeDay, System.Action onFinished = null)
    {
        titleText.text = $"gain card:{card.cardName}";
        acceptButtonText.text = "accept";
        cancelButtonText.text = "cancel";

        acceptAction = () =>
        {
            RunDataManager.Instance.AddCardToDeck(card);

            if (consumeDay)
            {
                ConsumeOneDayAndReturnHub();
            }
            else
            {
                onFinished?.Invoke();
            }
        };

        cancelAction = () =>
        {
            if (consumeDay)
            {
                ConsumeOneDayAndReturnHub();
            }
            else
            {
                onFinished?.Invoke();
            }
        };

        RefreshButtons();
        panelRoot.SetActive(true);
    }
    public void ShowRecipeReward(CardData recipeCard, bool consumeDay, System.Action onFinished = null)
    {
        titleText.text = $"gain recipe:{recipeCard.cardName}";
        acceptButtonText.text = "accept";
        cancelButtonText.text = "cancel";

        acceptAction = () =>
        {
            RunDataManager.Instance.UnlockRecipe(recipeCard);

            if (consumeDay)
            {
                ConsumeOneDayAndReturnHub();
            }
            else
            {
                onFinished?.Invoke();
            }
        };

        cancelAction = () =>
        {
            if (consumeDay)
            {
                ConsumeOneDayAndReturnHub();
            }
            else
            {
                onFinished?.Invoke();
            }
        };

        RefreshButtons();
        panelRoot.SetActive(true);
    }

    public void ShowBattleConfirm()
    {
        titleText.text = "there is a battle, do you want to join?";
        acceptButtonText.text = "accept battle";
        cancelButtonText.text = "cancel battle";

        acceptAction = () =>
        {
            if (RunDataManager.Instance != null)
            {
                RunDataManager.Instance.hasChosenEventToday = true;
            }

            SceneFlowManager.Instance.EnterBattleScene();
        };

        cancelAction = () =>
        {
            ConsumeOneDayAndReturnHub();
        };

        RefreshButtons();
        panelRoot.SetActive(true);
    }

    private void RefreshButtons()
    {
        acceptButton.onClick.RemoveAllListeners();
        acceptButton.onClick.AddListener(() =>
        {
            acceptAction?.Invoke();
            Hide();
        });

        cancelButton.onClick.RemoveAllListeners();
        cancelButton.onClick.AddListener(() =>
        {
            cancelAction?.Invoke();
            Hide();
        });
    }

    private void CloseWithoutChoice()
    {
        Hide();
    }

    private void ConsumeOneDayAndReturnHub()
    {
        if (RunDataManager.Instance != null)
        {
            RunDataManager.Instance.hasChosenEventToday = true;
            RunDataManager.Instance.AdvanceDay();
            RunDataManager.Instance.StartNewDay();
        }

        if (SceneFlowManager.Instance != null)
        {
            SceneFlowManager.Instance.EnterHubScene();
        }
    }

    public void Hide()
    {
        panelRoot.SetActive(false);
        acceptAction = null;
        cancelAction = null;
    }
}
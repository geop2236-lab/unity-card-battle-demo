using TMPro;
using UnityEngine;

public class BattleStatusPanelUI : MonoBehaviour
{
    [Header("玩家信息")]
    public TextMeshProUGUI playerToleranceText;
    public TextMeshProUGUI playerFixedDefText;
    public TextMeshProUGUI playerBuffText;

    [Header("敌人信息")]
    public TextMeshProUGUI enemyToleranceText;
    public TextMeshProUGUI enemyFixedDefText;
    public TextMeshProUGUI enemyBuffText;

    void Update()
    {
        RefreshUI();
    }

    public void RefreshUI()
    {
        if (GameManager.Instance == null) return;

        // 玩家承受能力
        if (playerToleranceText != null)
        {
            playerToleranceText.text = $"tolerance {GameManager.Instance.playerTolerance}";
        }

        // 玩家固定防御
        if (playerFixedDefText != null)
        {
            playerFixedDefText.text = $"str def {GameManager.Instance.playerFixedDef}";
        }

        // 玩家Buff
        if (playerBuffText != null)
        {
            playerBuffText.text = BuildBuffText(GameManager.Instance.playerStrength);
        }

        // 敌人承受能力
        if (enemyToleranceText != null)
        {
            int enemyCurrent = 0;
            int enemyLimit = 0;

            if (EnemyManager.Instance != null)
            {
                enemyCurrent = EnemyManager.Instance.currentScrap;
                enemyLimit = EnemyManager.Instance.scrapLimit;
            }

            enemyToleranceText.text = $"tolerance {GameManager.Instance.enemyTolerance}";
        }

        // 敌人固定防御
        if (enemyFixedDefText != null)
        {
            enemyFixedDefText.text = $"str def {GameManager.Instance.enemyFixedDef}";
        }

        // 敌人Buff
        if (enemyBuffText != null)
        {
            enemyBuffText.text = BuildBuffText(GameManager.Instance.enemyStrength);
        }
    }

    private string BuildBuffText(int strength)
    {
        string result = "";

        if (strength > 0)
        {
            result += $"strength {strength}";
        }

        if (string.IsNullOrEmpty(result))
        {
            result = "Null";
        }

        return result;
    }
}
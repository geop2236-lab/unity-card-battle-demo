using UnityEngine;
using TMPro;
using DG.Tweening;

public class PursuitFXManager : MonoBehaviour
{
    public static PursuitFXManager Instance { get; private set; }

    public GameObject overlayPanel;
    public TextMeshProUGUI promptText;

    private Tween textTween;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        if (overlayPanel != null) overlayPanel.SetActive(false);
    }

    // 开启特写
    public void ShowPursuitEffect()
    {
        if (overlayPanel == null) return;

        overlayPanel.SetActive(true);

        // 让文字有一个“砰”弹出来并持续呼吸的动画
        if (promptText != null)
        {
            promptText.transform.localScale = Vector3.zero;
            promptText.transform.DOScale(1f, 0.3f).SetEase(Ease.OutBack).OnComplete(() =>
            {
                // 呼吸效果 (放大缩小循环)
                textTween = promptText.transform.DOScale(1.1f, 0.5f).SetLoops(-1, LoopType.Yoyo);
            });
        }
    }

    // 关闭特写
    public void HidePursuitEffect()
    {
        if (overlayPanel == null) return;

        // 停止动画
        if (textTween != null) textTween.Kill();
        if (promptText != null) promptText.transform.localScale = Vector3.one;

        overlayPanel.SetActive(false);
    }
}
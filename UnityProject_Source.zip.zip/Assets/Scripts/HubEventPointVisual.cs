using UnityEngine;
using DG.Tweening;
using TMPro;
using UnityEngine.EventSystems;

public class HubEventPointVisual : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public RectTransform pulseRing;
    public RectTransform pointCore;
    public TextMeshProUGUI eventLabel;

    private Vector3 coreOriginalScale;
    private Tween pulseTween;

    void Start()
    {
        if (pointCore != null)
            coreOriginalScale = pointCore.localScale;

        if (eventLabel != null)
            eventLabel.gameObject.SetActive(false);

        if (pulseRing != null)
        {
            pulseRing.localScale = Vector3.one;
            pulseTween = pulseRing.DOScale(1.25f, 0.8f)
                .SetEase(Ease.InOutSine)
                .SetLoops(-1, LoopType.Yoyo);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (pointCore != null)
        {
            pointCore.DOKill();
            pointCore.DOScale(coreOriginalScale * 1.15f, 0.15f).SetEase(Ease.OutBack);
        }

        if (eventLabel != null)
            eventLabel.gameObject.SetActive(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (pointCore != null)
        {
            pointCore.DOKill();
            pointCore.DOScale(coreOriginalScale, 0.15f).SetEase(Ease.OutBack);
        }

        if (eventLabel != null)
            eventLabel.gameObject.SetActive(false);
    }
}
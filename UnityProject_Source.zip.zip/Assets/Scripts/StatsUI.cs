using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StatsUI : MonoBehaviour
{
    [Header("���״̬��")]
    public Slider playerSlider;
    public TextMeshProUGUI playerText;

    [Header("����״̬��")]
    public Slider enemySlider;
    public TextMeshProUGUI enemyText;

    [Header("������ʾ")]
    public TextMeshProUGUI playerBlockText;
    public TextMeshProUGUI enemyBlockText;
    void Update()
    {
        // Ϊ��ʡ�£�ֱ���� Update ��ˢ����������Ըĳ��¼�����
        UpdatePlayerUI();
        UpdateEnemyUI();
        UpdateBlockUI();
    }
    void UpdateBlockUI()
    {
        if (GameManager.Instance == null) return;

        // ��һ���
        if (playerBlockText)
        {
            int block = GameManager.Instance.playerBlock;
            playerBlockText.text = block > 0 ? $"BLOCK: {block}" : ""; // �жܲ���ʾ
            playerBlockText.gameObject.SetActive(block > 0);
        }

        // ���˻���
        if (enemyBlockText)
        {
            int block = GameManager.Instance.enemyBlock;
            enemyBlockText.text = block > 0 ? $"BLOCK: {block}" : "";
            enemyBlockText.gameObject.SetActive(block > 0);
        }
    }
    void UpdatePlayerUI()
    {
        if (GameManager.Instance == null) return;

        int current = GameManager.Instance.playerScrapCount;
        int max = GameManager.Instance.playerScrapLimit;

        if (playerSlider)
        {
            playerSlider.maxValue = max;
            playerSlider.value = current;
        }
        if (playerText) playerText.text = $"{current}/{max}";
    }

    void UpdateEnemyUI()
    {
        if (EnemyManager.Instance == null) return;

        int current = EnemyManager.Instance.currentScrap;
        int max = EnemyManager.Instance.scrapLimit;

        if (enemySlider)
        {
            enemySlider.maxValue = max;
            enemySlider.value = current;
        }
        if (enemyText) enemyText.text = $"{current}/{max}";
    }
}
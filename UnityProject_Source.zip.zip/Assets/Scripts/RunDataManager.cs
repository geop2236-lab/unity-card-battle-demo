using System.Collections.Generic;
using UnityEngine;
using System;
public enum RunEndResult
{
    None,
    Victory,
    Defeat
}
public class RunDataManager : MonoBehaviour
{
    public static RunDataManager Instance { get; private set; }
    public event Action OnRecipesChanged;

    [Header("本局当前牌组")]
    public List<CardData> currentDeck = new List<CardData>();
    [Header("待进入战斗的敌人")]
    public EnemyData pendingEnemy;
    [Header("本局已解锁配方（先直接存结果卡）")]
    public List<CardData> unlockedRecipeCards = new List<CardData>();

    [Header("初始数据")]
    public List<CardData> startingDeck = new List<CardData>();
    public List<CardData> startingUnlockedRecipeCards = new List<CardData>();
    [Header("流程进度")]
    public int currentDay = 1;
    public int maxDay = 7;
    public bool hasChosenEventToday = false;
    [Header("结局状态")]
    public RunEndResult endResult = RunEndResult.None;
    [Header("跨战斗废卡")]
    public int persistentWasteCount = 0;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            hasChosenEventToday = false;
            DontDestroyOnLoad(gameObject);
            InitializeRunData();
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public bool IsFinalDay()
    {
        return currentDay >= maxDay;
    }

    public void AdvanceDay()
    {
        currentDay++;
        Debug.Log($"[RunDataManager] 天数推进到：Day {currentDay}");
    }
    public void StartNewDay()
    {
        hasChosenEventToday = false;
    }

    public void MarkEventChosen()
    {
        hasChosenEventToday = true;
    }
    public bool IsRunFinished()
    {
        return currentDay > maxDay;
    }
    public void InitializeRunData()
    {
        currentDay = 1;
        currentDeck = new List<CardData>(startingDeck);
        unlockedRecipeCards = new List<CardData>(startingUnlockedRecipeCards);
        pendingEnemy = null;
        Debug.Log($"[RunDataManager] ready ：cards {currentDeck.Count} ，recipes {unlockedRecipeCards.Count} ");
        persistentWasteCount = 0;
        OnRecipesChanged?.Invoke();
        endResult = RunEndResult.None;
    }

    public void AddCardToDeck(CardData card)
    {
        if (card == null) return;

        currentDeck.Add(card);
        Debug.Log($"[RunDataManager] card added：{card.cardName}");
    }

    public void UnlockRecipe(CardData card)
    {
        if (card == null) return;

        if (unlockedRecipeCards.Contains(card))
        {
            Debug.Log($"[RunDataManager] recipe already unlocked：{card.cardName}");
            return;
        }

        unlockedRecipeCards.Add(card);
        Debug.Log($"[RunDataManager] recipe unlocked：{card.cardName}");

        OnRecipesChanged?.Invoke();
    }

    public bool HasRecipe(CardData card)
    {
        return unlockedRecipeCards.Contains(card);
    }
}
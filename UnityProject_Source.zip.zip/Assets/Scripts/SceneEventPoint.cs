using TMPro;
using UnityEngine;

public class SceneEventPoint : MonoBehaviour
{
    public HubEventDefinition assignedEvent;

    [Header("可选：场景点位显示文字")]
    public TextMeshProUGUI eventNameText;

    public void AssignEvent(HubEventDefinition newEvent)
    {
        assignedEvent = newEvent;

        if (eventNameText != null)
        {
            eventNameText.text = assignedEvent != null ? assignedEvent.eventName : "空事件";
        }

        Debug.Log($"[SceneEventPoint] 已分配事件：{assignedEvent?.eventName}");
    }

    public void TriggerEvent()
    {
        if (assignedEvent == null)
        {
            Debug.LogWarning("[SceneEventPoint] 当前没有分配事件");
            return;
        }

        if (RewardPopupUI.Instance == null) return;

        switch (assignedEvent.eventType)
        {
            case HubEventType.GetCard:
                RewardPopupUI.Instance.ShowCardReward(assignedEvent.rewardCard, true);
                break;

            case HubEventType.GetRecipe:
                RewardPopupUI.Instance.ShowRecipeReward(assignedEvent.rewardCard, true);
                break;

            case HubEventType.Battle:
                if (RunDataManager.Instance != null)
                {
                    RunDataManager.Instance.pendingEnemy = assignedEvent.enemyData;
                }
                RewardPopupUI.Instance.ShowBattleConfirm();
                break;
        }
    }
}
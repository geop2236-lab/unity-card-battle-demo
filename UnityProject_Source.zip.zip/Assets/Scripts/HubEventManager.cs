using System.Collections.Generic;
using UnityEngine;

public class HubEventManager : MonoBehaviour
{
    [Header("场上的3个事件点")]
    public List<SceneEventPoint> eventPoints = new List<SceneEventPoint>();

    [Header("6个可用位置锚点")]
    public List<RectTransform> pointAnchors = new List<RectTransform>();

    [Header("普通事件池")]
    public List<HubEventDefinition> normalEventPool = new List<HubEventDefinition>();

    [Header("最终日Boss事件")]
    public HubEventDefinition finalBossEvent;

    [Header("是否允许重复事件")]
    public bool allowDuplicates = false;

    void Start()
    {
        GenerateTodayEvents();
    }

    public void GenerateTodayEvents()
    {
        if (RunDataManager.Instance == null)
        {
            Debug.LogWarning("[HubEventManager] RunDataManager 不存在");
            return;
        }

        if (eventPoints.Count == 0)
        {
            Debug.LogWarning("[HubEventManager] 没有配置事件点");
            return;
        }

        if (pointAnchors.Count < eventPoints.Count)
        {
            Debug.LogWarning("[HubEventManager] 锚点数量不足");
            return;
        }

        // 先全部隐藏
        foreach (var point in eventPoints)
        {
            point.gameObject.SetActive(false);
        }

        int activePointCount = GetActivePointCountByDay(RunDataManager.Instance.currentDay);

        // 随机选今天使用的锚点
        List<RectTransform> availableAnchors = new List<RectTransform>(pointAnchors);

        // 最后一天：只出一个 Boss 战
        if (RunDataManager.Instance.IsFinalDay())
        {
            if (finalBossEvent == null)
            {
                Debug.LogWarning("[HubEventManager] 最终日没有配置 finalBossEvent");
                return;
            }

            int randomAnchorIndex = Random.Range(0, availableAnchors.Count);
            RectTransform selectedAnchor = availableAnchors[randomAnchorIndex];

            SceneEventPoint point = eventPoints[0];
            RectTransform pointRect = point.GetComponent<RectTransform>();
            pointRect.position = selectedAnchor.position;

            point.AssignEvent(finalBossEvent);
            point.gameObject.SetActive(true);

            Debug.Log("[HubEventManager] 最终日：已生成 Boss 战事件");
            return;
        }

        // 非最终日：正常随机事件
        if (normalEventPool.Count == 0)
        {
            Debug.LogWarning("[HubEventManager] 普通事件池为空");
            return;
        }

        List<HubEventDefinition> availableEvents = new List<HubEventDefinition>(normalEventPool);

        for (int i = 0; i < activePointCount; i++)
        {
            // 1. 随机位置
            int randomAnchorIndex = Random.Range(0, availableAnchors.Count);
            RectTransform selectedAnchor = availableAnchors[randomAnchorIndex];
            availableAnchors.RemoveAt(randomAnchorIndex);

            SceneEventPoint point = eventPoints[i];
            RectTransform pointRect = point.GetComponent<RectTransform>();
            pointRect.position = selectedAnchor.position;

            // 2. 随机事件
            HubEventDefinition selectedEvent = null;

            if (allowDuplicates)
            {
                int randomEventIndex = Random.Range(0, normalEventPool.Count);
                selectedEvent = normalEventPool[randomEventIndex];
            }
            else
            {
                if (availableEvents.Count == 0)
                {
                    int randomEventIndex = Random.Range(0, normalEventPool.Count);
                    selectedEvent = normalEventPool[randomEventIndex];
                }
                else
                {
                    int randomEventIndex = Random.Range(0, availableEvents.Count);
                    selectedEvent = availableEvents[randomEventIndex];
                    availableEvents.RemoveAt(randomEventIndex);
                }
            }

            point.AssignEvent(selectedEvent);
            point.gameObject.SetActive(true);
        }

        Debug.Log($"[HubEventManager] Day {RunDataManager.Instance.currentDay}：生成了 {activePointCount} 个事件");
    }

    private int GetActivePointCountByDay(int day)
    {
        if (day <= 4) return 3;
        if (day <= 6) return 2;
        return 1;
    }
}
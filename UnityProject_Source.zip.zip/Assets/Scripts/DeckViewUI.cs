using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class DeckViewUI : MonoBehaviour
{
    [Header("��ڰ�ť")]
    public Button drawPileBtn;
    public TextMeshProUGUI drawCountText;
    public Button discardPileBtn;
    public TextMeshProUGUI discardCountText;

    [Header("չʾ���")]
    public GameObject browserPanel;
    public Transform contentRoot; // ScrollView �� Content
    public GameObject cardDisplayPrefab; // ����Ԥ�Ƽ�
    public TextMeshProUGUI titleText; // ��ʾ "���ƶ�" �� "���ƶ�"
    public Button closeButton;

    private void Start()
    {
        if (browserPanel != null)
        {
            browserPanel.SetActive(false);
        }
        // �󶨰�ť�¼�
        drawPileBtn.onClick.AddListener(() => ShowPile(true));
        discardPileBtn.onClick.AddListener(() => ShowPile(false));

        if (closeButton != null)
        {
            closeButton.onClick.AddListener(CloseBrowser);
        }
        // ��ʼˢ������
        UpdateCounts();
    }

    private void Update()
    {
        // ÿ֡ˢ������ (��������Ը����¼������Ż�����)
        UpdateCounts();
    }

    void UpdateCounts()
    {
        if (DeckManager.Instance == null) return;

        if (drawCountText) drawCountText.text = $"drawPileBtn: {DeckManager.Instance.drawPile.Count}";
        if (discardCountText) discardCountText.text = $"discardPileBtn: {DeckManager.Instance.discardPile.Count}";
    }

    // �����
    void ShowPile(bool isDrawPile)
    {
        if (DeckManager.Instance == null) return;

        browserPanel.SetActive(true);
        titleText.text = isDrawPile ? "DrawPile" : "discardPile";

        // 1. ��վ�����
        foreach (Transform child in contentRoot) Destroy(child.gameObject);

        // 2. ��ȡ�����б�
        List<CardData> listToShow = isDrawPile ? DeckManager.Instance.drawPile : DeckManager.Instance.discardPile;

        // 3. ���ɿ���
        foreach (CardData data in listToShow)
        {
            GameObject newCard = Instantiate(cardDisplayPrefab, contentRoot, false);

            RectTransform rt = newCard.GetComponent<RectTransform>();
            if (rt != null)
            {
                rt.localRotation = Quaternion.identity;
                rt.localScale = Vector3.one;

                Vector3 localPos = rt.localPosition;
                localPos.z = 0f;
                rt.localPosition = localPos;
            }

            // ��ʼ����ʾ
            CardUI ui = newCard.GetComponentInChildren<CardUI>();
            if (ui)
            {
                ui.Init(data);
            }
            else
            {
                Debug.LogWarning("[DeckViewUI] ���ɵĿ������Ҳ��� CardUI");
            }

            // ���ý������ƿ����ֻ�ǲ鿴��������
            Draggable drag = newCard.GetComponent<Draggable>();
            if (drag)
            {
                Destroy(drag);
            }

            LaneCardDraggable laneDrag = newCard.GetComponent<LaneCardDraggable>();
            if (laneDrag)
            {
                Destroy(laneDrag);
            }

            CanvasGroup cg = newCard.GetComponent<CanvasGroup>();
            if (cg != null)
            {
                cg.blocksRaycasts = false;
            }
        }
    }

    // �󶨸��رհ�ť
    public void CloseBrowser()
    {
        browserPanel.SetActive(false);
    }
}